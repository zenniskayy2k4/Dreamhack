#!/bin/sh
set -e
if [ ! -f "$MODEL_PATH" ]; then
  echo "[error] MODEL_PATH not found: $MODEL_PATH"; exit 1
fi

/app/bin/llama-server \
  -m "$MODEL_PATH" \
  -c "$CTX" -t "$THREADS" -ngl 0 \
  --host "$LLAMA_HOST" --port "$LLAMA_PORT" \
  > /tmp/llama.log 2>&1 &

python - <<'PY'
import time, urllib.request
URL="http://127.0.0.1:8080/health"
for _ in range(60):
    try:
        with urllib.request.urlopen(URL, timeout=0.5) as r:
            if r.status==200: break
    except Exception: pass
    time.sleep(0.2)
PY

exec python /app/app.py
